package org.zhong.common.code_generate.core.utils;

public class GenerateException extends Exception{
	public GenerateException(){ 
		super();
	}
	public GenerateException(String msg){
		super(msg);
	}
}
