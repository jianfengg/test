package org.zhong.common.code_generate;

import java.io.IOException;
import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.zhong.common.code_generate.core.Generater;
import org.zhong.common.code_generate.core.utils.GenerateException;

public class Client {


//	<value>tr_order</value>
//	<value>tr_order_charging</value>
//	<value>tr_order_charging_detail</value>
//	<value>tr_order_coupon</value>
//	<value>tr_order_log</value>
//	<value>tr_order_park</value>
//	<value>tr_order_relation</value>
//	<value>tr_order_wash</value>
//	<value>tr_pay_record</value>
//	<value>tr_refund</value>
//	<value>tr_refund_audit</value>
	public static void  main(String[] str) throws Exception{
		ApplicationContext ctx =  new ClassPathXmlApplicationContext("classpath:generate.xml");
		final Generater generater = (Generater) ctx.getBean("generate");

//		generater.generateAppRest("pt_cfg_biz_param");
//		generater.generateAppRest("pt_cfg_shared_dealer");
//		generater.generateAppRest("pt_cfg_shared_parts");
//		generater.generateAppRest("pt_parts_warehouse");
//		generater.generateAppRest("pt_parts_warehouse_storage_location");
//		generater.generateAppRest("pt_parts_supplier");
//		generater.generateAppRest("pt_parts_customer");


		generaterAll("mt_electronic_insurance_details",generater);
//		generater.generatePageReqDto("mt_electronic_insurance");

		//生成所有组件
//		generater.generateICommandApi("pt_oem_deliver_order");
//		generater.generateCommandApi("pt_parts_replace_relation");
//		generater.generateICommandService("pt_oem_deliver_order");
//		generater.generateCommandService("pt_parts_replace_relation");
		

//		generater.generateIQueryService("pt_parts_replace_relation");
//		generater.generateQueryService("pt_parts_replace_relation");
//		generater.generateIQueryApi("pt_parts_replace_relation");
//		generater.generateQueryApi("pt_parts_replace_relation");
//		generater.generateAppRest("pt_parts_replace_relation");
		//generater.generateRest("pt_parts_replace_relation");
		
		//generater.generateAppRest("pt_parts_replace_relation");
//		generater.generateAppRest("pt_parts_supplier");
//		generater.generateAppRest("pt_parts_customer");
//		generater.generateAppRest("pt_parts_warehouse");
//		generater.generateAppRest("pt_parts_warehouse_storage_location");
//		generater.generateAppRest("pt_cfg_biz_param");
//		generater.generateAppRest("pt_cfg_shared_dealer");
//		generater.generateAppRest("pt_cfg_shared_parts");

//		generater.generateRest("pt_parts");
//		generater.generateRest("pt_parts_replace_relation");
//		generater.generateRest("pt_parts_supplier");
//		generater.generateRest("pt_parts_customer");
//		generater.generateRest("pt_parts_warehouse");
//		generater.generateRest("pt_parts_warehouse_storage_location");
//		generater.generateRest("pt_cfg_biz_param");
//		generater.generateRest("pt_cfg_shared_dealer");
//		generater.generateRest("pt_cfg_shared_parts");

		//同时生成多个表的Dao
//		generaterDao("tr_order_coupon", generater);
//		generaterDao("tr_order_charging_detail", generater);
//		generaterDao("tr_order_log", generater);
//		generaterDao("tr_order_park", generater);
//		generaterDao("tr_order_relation", generater);
//		generaterDao("tr_order_wash", generater);
//		generaterDao("tr_refund_audit", generater);

		//生成单个组件
//		generater.generateEo("tr_order_charging");
//		generater.generateDto("tr_order_charging");
//		generater.generateMapper("tr_order_charging");
//		generater.generateDas("tr_order_charging");
//		generater.generateICommandService("mk_activity");
//		generater.generateCommandService("mk_activity");
//		generater.generateIQueryService("mk_activity");
//		generater.generateQueryService("mk_activity");
//		generater.generateICommandApi("mk_activity");
//		generater.generateCommandApi("mk_activity");
//		generater.generateIQueryApi("mk_activity");
//		generater.generateQueryApi("mk_activity");
//		generater.generateRest("mk_activity");



//		String[] tables = new String[]{"mk_activity"};
//		generater.bacthGenerate(tables,new Batch() {
//			public void bacth(String tableName) throws Exception {
//				gAll(tableName, generater);
//			}
//		});

		/*这是批量生成事列
		//批量生成全部配置了的实体
		g.bacthGenerate(new Batch() {
			public void bacth(String tableName) throws Exception {
				g.gEntity(tableName);
			}
		});

		//批量生成全部配置了的Dao
		g.bacthGenerate(new Batch() {
			public void bacth(String tableName) throws Exception {
				g.gDao(tableName);
			}
		});


		选择性批量生成实体
		String[] tables = new String[]{"flowAttach","manufactureFlowPro","sameTimeSongFlag","manufactureFlow"};
		g.bacthGenerate(tables,new Batch() {
			public void bacth(String tableName) throws Exception {
				g.gEntity(tableName);
			}
		});*/




	}

	public static void generaterDao(String tableName,Generater generater) throws IOException, GenerateException, SQLException{
		generater.generateEo(tableName);
		generater.generateDto(tableName);
		generater.generateMapper(tableName);
		generater.generateDas(tableName);
	}
	
	public static void generaterBiz(String tableName,Generater generater) throws IOException, GenerateException, SQLException{
		generater.generateICommandService(tableName);
		generater.generateCommandService(tableName);
		generater.generateIQueryService(tableName);
		generater.generateQueryService(tableName);
		generater.generateICommandApi(tableName);
		generater.generateCommandApi(tableName);
		generater.generateIQueryApi(tableName);
		generater.generateQueryApi(tableName);
		generater.generateRest(tableName);
	}

	public static void generaterAll(String tableName,Generater generater) throws IOException, GenerateException, SQLException{
		generater.generateEo(tableName);
		generater.generateDto(tableName);
		generater.generateMapper(tableName);
		generater.generateDas(tableName);
//		generater.generateICommandService(tableName);
//		generater.generateCommandService(tableName);
//		generater.generateIQueryService(tableName);
//		generater.generateQueryService(tableName);
//		generater.generateICommandApi(tableName);
//		generater.generateCommandApi(tableName);
//		generater.generateIQueryApi(tableName);
//		generater.generateQueryApi(tableName);
//		generater.generateRest(tableName);
//		generater.generateAppRest(tableName);
	}
}
