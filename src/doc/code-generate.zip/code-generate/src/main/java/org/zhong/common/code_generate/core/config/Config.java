package org.zhong.common.code_generate.core.config;

import org.zhong.common.code_generate.core.utils.GenerateException;

public class Config {
	static String pjp = System.getProperty("user.dir");

	private String tmpl = "/code-generate/src/main/java/org/zhong/common/code_generate/tpl";
	private String tmplEo = "eo.ftl";
	private String tmplDto = "dto.ftl";
	private String tmplMapper = "mapper.ftl";
	private String tmplDas = "das.ftl";
	private String tmplICommandApi = "icommandApi.ftl";
	private String tmplCommandApi = "commandApi.ftl";
	private String tmplIQueryApi = "iqueryApi.ftl";
	private String tmplQueryApi = "queryApi.ftl";
	private String tmplICommandService = "icommandService.ftl";
	private String tmplCommandService = "commandService.ftl";
	private String tmplIQueryService = "iqueryService.ftl";
	private String tmplQueryService = "queryService.ftl";
	private String tmplRest = "rest.ftl";
	private String tmplAppRest = "appRest.ftl";
	private String tmplPageReqDto = "pageReqDto.ftl";
	
	

	private String src = "/src";
	private String webRoot = "/WebRoot";
	private String saveEo ="pack:org.webapp.base.generate.test";
	private String saveDto = "pack:org.webapp.base.generate.test";
	private String saveMapper ="pack:org.webapp.base.generate.test";
	private String saveDas = "pack:org.webapp.base.generate.test";
	private String saveICommandApi = "pack:org.webapp.base.generate.test";
	private String saveCommandApi = "pack:org.webapp.base.generate.test";
	private String saveIQueryApi = "pack:org.webapp.base.generate.test";
	private String saveQueryApi = "pack:org.webapp.base.generate.test";
	private String saveICommandService = "pack:org.webapp.base.generate.test";
	private String saveCommandService = "pack:org.webapp.base.generate.test";
	private String saveIQueryService = "pack:org.webapp.base.generate.test";
	private String saveQueryService = "pack:org.webapp.base.generate.test";
	private String saveRest = "pack:org.webapp.base.generate.test";


	/**
	 * 转换路径
	 * @param pakagename
	 * @param i
	 * @return
	 * @throws GenerateException
	 */
	public String path(String path) throws GenerateException{
		String[] s = path.split(":");
		if(s.length!=2)
			throw new GenerateException("路径没按规则编写:"+path);
		if(s[0].equals("pack")){
			return pjp+"/"+src+"/"+s[1].replace('.','/');
		}else if(s[0].equals("web")){
			return pjp+"/"+webRoot+"/"+s[1].replace('.','/');
		}else{
			throw new GenerateException("路径没按规则编写:"+path);
		}
	}


	private String getPackage(String s1) throws GenerateException{
		String[] s = s1.split(":");
		if(s.length!=2)
			throw new GenerateException("路径没按规则编写:"+s1);
		if(s[0].equals("pack")){
			return s[1];
		}else{
			throw new GenerateException("路径没按规则编写:"+s1);
		}
	}

	public String getEoPackage() throws GenerateException{
		return getPackage(saveEo);
	}

	public String getDtoPackage() throws GenerateException{
		return getPackage(saveDto);
	}

	public String getMapperPackage() throws GenerateException{
		return getPackage(saveMapper);
	}

	public String getDasPackage() throws GenerateException{
		return getPackage(saveDas);
	}

	public String getICommandApiPackage() throws GenerateException{
		return getPackage(saveICommandApi);
	}

	public String getCommandApiPackage() throws GenerateException{
		return getPackage(saveCommandApi);
	}

	public String getIQueryApiPackage() throws GenerateException{
		return getPackage(saveIQueryApi);
	}

	public String getQueryApiPackage() throws GenerateException{
		return getPackage(saveQueryApi);
	}

	public String getICommandServicePackage() throws GenerateException{
		return getPackage(saveICommandService);
	}


	public String getCommandServicePackage() throws GenerateException{
		return getPackage(saveCommandService);
	}


	public String getIQueryServicePackage() throws GenerateException{
		return getPackage(saveIQueryService);
	}


	public String getQueryServicePackage() throws GenerateException{
		return getPackage(saveQueryService);
	}



	public String getTmpl() {
		return "file:"+pjp+tmpl;
	}
	public void setTmpl(String tmpl) {
		this.tmpl = tmpl;
	}


	public String getTmplEo() {
		return tmplEo;
	}


	public void setTmplEo(String tmplEo) {
		this.tmplEo = tmplEo;
	}


	public String getTmplDto() {
		return tmplDto;
	}


	public void setTmplDto(String tmplDto) {
		this.tmplDto = tmplDto;
	}




	public String getTmplMapper() {
		return tmplMapper;
	}


	public void setTmplMapper(String tmplMapper) {
		this.tmplMapper = tmplMapper;
	}


	public String getSaveMapper() {
		return saveMapper;
	}


	public void setSaveMapper(String saveMapper) {
		this.saveMapper = saveMapper;
	}


	public String getSrc() {
		return src;
	}


	public void setSrc(String src) {
		this.src = src;
	}

	public String getSaveEo() {
		return saveEo;
	}


	public void setSaveEo(String saveEo) {
		this.saveEo = saveEo;
	}


	public String getSaveDto() {
		return saveDto;
	}


	public void setSaveDto(String saveDto) {
		this.saveDto = saveDto;
	}


	public static String getPjp() {
		return pjp;
	}


	public static void setPjp(String pjp) {
		Config.pjp = pjp;
	}


	public String getTmplDas() {
		return tmplDas;
	}


	public void setTmplDas(String tmplDas) {
		this.tmplDas = tmplDas;
	}


	public String getTmplICommandApi() {
		return tmplICommandApi;
	}


	public void setTmplICommandApi(String tmplICommandApi) {
		this.tmplICommandApi = tmplICommandApi;
	}


	public String getTmplCommandApi() {
		return tmplCommandApi;
	}


	public void setTmplCommandApi(String tmplCommandApi) {
		this.tmplCommandApi = tmplCommandApi;
	}


	public String getTmplIQueryApi() {
		return tmplIQueryApi;
	}


	public void setTmplIQueryApi(String tmplIQueryApi) {
		this.tmplIQueryApi = tmplIQueryApi;
	}


	public String getTmplQueryApi() {
		return tmplQueryApi;
	}


	public void setTmplQueryApi(String tmplQueryApi) {
		this.tmplQueryApi = tmplQueryApi;
	}


	public String getTmplICommandService() {
		return tmplICommandService;
	}


	public void setTmplICommandService(String tmplICommandService) {
		this.tmplICommandService = tmplICommandService;
	}


	public String getTmplCommandService() {
		return tmplCommandService;
	}


	public void setTmplCommandService(String tmplCommandService) {
		this.tmplCommandService = tmplCommandService;
	}


	public String getTmplIQueryService() {
		return tmplIQueryService;
	}


	public void setTmplIQueryService(String tmplIQueryService) {
		this.tmplIQueryService = tmplIQueryService;
	}


	public String getTmplQueryService() {
		return tmplQueryService;
	}


	public void setTmplQueryService(String tmplQueryService) {
		this.tmplQueryService = tmplQueryService;
	}


	public String getWebRoot() {
		return webRoot;
	}


	public void setWebRoot(String webRoot) {
		this.webRoot = webRoot;
	}


	public String getSaveDas() {
		return saveDas;
	}


	public void setSaveDas(String saveDas) {
		this.saveDas = saveDas;
	}


	public String getSaveICommandApi() {
		return saveICommandApi;
	}


	public void setSaveICommandApi(String saveICommandApi) {
		this.saveICommandApi = saveICommandApi;
	}


	public String getSaveCommandApi() {
		return saveCommandApi;
	}


	public void setSaveCommandApi(String saveCommandApi) {
		this.saveCommandApi = saveCommandApi;
	}


	public String getSaveIQueryApi() {
		return saveIQueryApi;
	}


	public void setSaveIQueryApi(String saveIQueryApi) {
		this.saveIQueryApi = saveIQueryApi;
	}


	public String getSaveQueryApi() {
		return saveQueryApi;
	}


	public void setSaveQueryApi(String saveQueryApi) {
		this.saveQueryApi = saveQueryApi;
	}


	public String getSaveICommandService() {
		return saveICommandService;
	}


	public void setSaveICommandService(String saveICommandService) {
		this.saveICommandService = saveICommandService;
	}


	public String getSaveCommandService() {
		return saveCommandService;
	}


	public void setSaveCommandService(String saveCommandService) {
		this.saveCommandService = saveCommandService;
	}


	public String getSaveIQueryService() {
		return saveIQueryService;
	}


	public void setSaveIQueryService(String saveIQueryService) {
		this.saveIQueryService = saveIQueryService;
	}


	public String getSaveQueryService() {
		return saveQueryService;
	}


	public void setSaveQueryService(String saveQueryService) {
		this.saveQueryService = saveQueryService;
	}


	public String getTmplRest() {
		return tmplRest;
	}


	public void setTmplRest(String tmplRest) {
		this.tmplRest = tmplRest;
	}


	public String getSaveRest() {
		return saveRest;
	}


	public void setSaveRest(String saveRest) {
		this.saveRest = saveRest;
	}


	public String getTmplAppRest() {
		return tmplAppRest;
	}


	public void setTmplAppRest(String tmplAppRest) {
		this.tmplAppRest = tmplAppRest;
	}


	public String getTmplPageReqDto() {
		return tmplPageReqDto;
	}


	public void setTmplPageReqDto(String tmplPageReqDto) {
		this.tmplPageReqDto = tmplPageReqDto;
	}
	
	

	

	










}
