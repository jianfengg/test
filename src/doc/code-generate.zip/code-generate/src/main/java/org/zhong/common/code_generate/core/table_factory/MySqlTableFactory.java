package org.zhong.common.code_generate.core.table_factory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.zhong.common.code_generate.core.bean.Column;
import org.zhong.common.code_generate.core.bean.Table;
import org.zhong.common.code_generate.core.utils.GenerateException;

public class MySqlTableFactory extends TableFactory{

	public MySqlTableFactory(){
		super();
	}
	public MySqlTableFactory(Connection conn) {
		super(conn);
	}




	@Override
	public List<Table> getTables() throws GenerateException, SQLException {
		if(tableNames==null){
			throw new GenerateException("table列表为空");
		}
		List<Table> list = new ArrayList();
		for(int i=0;i<tableNames.length;i++){
			list.add(getTable(tableNames[i]));
		}
		return list;
	}

	@Override
	public Map<String, Table> getMapTables() throws GenerateException, SQLException {
		if(tableNames==null){
			throw new GenerateException("table列表为空");
		}
		Map<String,Table> map = new HashMap<String, Table>();
		for(int i=0;i<tableNames.length;i++){
			map.put(tableNames[i], getTable(tableNames[i]));
		}
		return map;
	}

	public Table getTable(String tableName) throws SQLException, GenerateException{
		String tablesql = "SHOW TABLE  STATUS  from "+getDbName()+" where name=?";
		Table table = new Table();
		Connection conn = getConn();
		try {
			PreparedStatement pst = conn.prepareStatement(tablesql);
			ResultSet rs = null;
			pst.setString(1,tableName);
			rs = pst.executeQuery();
			int i=0;
			while(rs.next()){
				table.setTableName(tableName);
				table.setRemark(rs.getString("Comment"));
				i++;
			}
			if(i<1){
				throw new GenerateException("请检查generate.xml的表名："+tableName+"配置是否与数据库一致");
			}
			convertTable(table);//配置其他信息
			table.setColumns(getColumns(tableName));
		} finally {
			conn.close();
		}

		return table;
	}

	private List<Column> getColumns(String tableName) throws SQLException{
		 String columnsql= "SHOW FULL FIELDS FROM  "+tableName;
		List<Column> list = new ArrayList<Column>();
		Connection conn = getConn();
		try {
			PreparedStatement pst = conn.prepareStatement(columnsql);
			ResultSet rs = null;
		//	pst.setString(1,tableName);
			rs = pst.executeQuery();

			Column c = null;
			while(rs.next()){

				c = new Column();
				c.setIsnull("YES".equals(rs.getString("Null")) ? "1" :"0" );
				c.setName(rs.getString("Field"));
				c.setRemark(rs.getString("Comment"));
				c.setIsprimary("PRI".equals(rs.getString("Key"))?"1":"0");

				String type = rs.getString("Type");
				int star = type.indexOf('(');
				int end = type.indexOf(')');
				if(star>-1){
					c.setType(type.substring(0,star));
					c.setLength(type.substring(star+1, end));
				}else{
					c.setType(type);
					String length="10";
					if(type.equals("date")){
						length="20";
					}else if(type.equals("int")){
						length="11";
					}else if(type.equals("float")){
						length="20";
					}
					c.setLength(length);
				}



				convertColumn(c);//配置其他信息
				list.add(c);
			}
		} finally {
			conn.close();
			// TODO: handle finally clause
		}

		return list;
	}









}
