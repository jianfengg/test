package  org.zhong.common.code_generate.test;

import org.zhong.common.code_generate.test.ElectronicInsuranceDetailsEo;
import org.springframework.stereotype.Service;
import org.zhong.common.code_generate.test.base.AbstractBaseDas;

/**
* 电子保单详情Das类
*/
@Service
public class ElectronicInsuranceDetailsDas extends AbstractBaseDas<ElectronicInsuranceDetailsEo,String>{

}
