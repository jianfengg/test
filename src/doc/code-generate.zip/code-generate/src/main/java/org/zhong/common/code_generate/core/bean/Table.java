package org.zhong.common.code_generate.core.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Table {
	String tableName;
	String remark;
	List<Column> columns = new ArrayList<Column>();

	String entityName;//生成的java的实体名
	List<Attach> attachs;

	private Map<String,Object> tableMap;
	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public List<Column> getColumns() {
		return columns;
	}

	public void setColumns(List<Column> columns) {
		this.columns = columns;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}


	public List<Attach> getAttachs() {
		return attachs;
	}

	public void setAttachs(List<Attach> attachs) {
		this.attachs = attachs;
	}

	public Map<String, Object> getTableMap() {
		return tableMap;
	}

	public void setTableMap(Map<String, Object> tableMap) {
		this.tableMap = tableMap;
	}














}
