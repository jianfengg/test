package org.zhong.common.code_generate.test;

import java.util.Date;
import com.dtyunxi.dto.RequestDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;

/**
*  电子保单详情Dto对象
*/
@ApiModel(value = "ElectronicInsuranceDetailsDto", description = "ElectronicInsuranceDetailsDto对象")
public class ElectronicInsuranceDetailsDto extends RequestDto{

    /**
     *  ID
     *  
     */
    @ApiModelProperty(name = "id", value = " ID  ", allowEmptyValue = true)
    private Long id;

    /**
     *  创建人账户名称
     *  
     */
    @ApiModelProperty(name = "createPerson", value = " 创建人账户名称  ", allowEmptyValue = true)
    private String createPerson;

    /**
     *  创建时间
     *  
     */
    @ApiModelProperty(name = "createTime", value = " 创建时间  ", allowEmptyValue = true)
    private Date createTime;

    /**
     *  修改人账户名称
     *  
     */
    @ApiModelProperty(name = "updatePerson", value = " 修改人账户名称  ", allowEmptyValue = true)
    private String updatePerson;

    /**
     *  更新时间
     *  
     */
    @ApiModelProperty(name = "updateTime", value = " 更新时间  ", allowEmptyValue = true)
    private Date updateTime;

    /**
     *  描述
     *  
     */
    @ApiModelProperty(name = "remark", value = " 描述  ", allowEmptyValue = true)
    private String remark;

    /**
     *  主单id
     *  
     */
    @ApiModelProperty(name = "masterId", value = " 主单id  ", allowEmptyValue = true)
    private Long masterId;

    /**
     *  保险公司
     *  
     */
    @ApiModelProperty(name = "insuranceCompany", value = " 保险公司  ", allowEmptyValue = true)
    private String insuranceCompany;

    /**
     *  所属险种
     *  
     */
    @ApiModelProperty(name = "insuranceType", value = " 所属险种  ", allowEmptyValue = true)
    private Integer insuranceType;

    /**
     *  保险产品
     *  
     */
    @ApiModelProperty(name = "insuranceProduct", value = " 保险产品  ", allowEmptyValue = true)
    private String insuranceProduct;

    /**
     *  保单号
     *  
     */
    @ApiModelProperty(name = "no", value = " 保单号  ", allowEmptyValue = true)
    private String no;

    /**
     *  保险金额
     *  
     */
    @ApiModelProperty(name = "insuredAmount", value = " 保险金额  ", allowEmptyValue = true)
    private BigDecimal insuredAmount;

    /**
     *  开单日期
     *  
     */
    @ApiModelProperty(name = "billingDate", value = " 开单日期  ", allowEmptyValue = true)
    private Date billingDate;

    /**
     *  保险起期
     *  
     */
    @ApiModelProperty(name = "startDate", value = " 保险起期  ", allowEmptyValue = true)
    private Date startDate;

    /**
     *  保险止期
     *  
     */
    @ApiModelProperty(name = "endDate", value = " 保险止期  ", allowEmptyValue = true)
    private Date endDate;


    public void setId(Long id){
        this.id = id;
    }
    public Long getId(){
        return this.id;
    }

    public void setCreatePerson(String createPerson){
        this.createPerson = createPerson;
    }
    public String getCreatePerson(){
        return this.createPerson;
    }

    public void setCreateTime(Date createTime){
        this.createTime = createTime;
    }
    public Date getCreateTime(){
        return this.createTime;
    }

    public void setUpdatePerson(String updatePerson){
        this.updatePerson = updatePerson;
    }
    public String getUpdatePerson(){
        return this.updatePerson;
    }

    public void setUpdateTime(Date updateTime){
        this.updateTime = updateTime;
    }
    public Date getUpdateTime(){
        return this.updateTime;
    }

    public void setRemark(String remark){
        this.remark = remark;
    }
    public String getRemark(){
        return this.remark;
    }

    public void setMasterId(Long masterId){
        this.masterId = masterId;
    }
    public Long getMasterId(){
        return this.masterId;
    }

    public void setInsuranceCompany(String insuranceCompany){
        this.insuranceCompany = insuranceCompany;
    }
    public String getInsuranceCompany(){
        return this.insuranceCompany;
    }

    public void setInsuranceType(Integer insuranceType){
        this.insuranceType = insuranceType;
    }
    public Integer getInsuranceType(){
        return this.insuranceType;
    }

    public void setInsuranceProduct(String insuranceProduct){
        this.insuranceProduct = insuranceProduct;
    }
    public String getInsuranceProduct(){
        return this.insuranceProduct;
    }

    public void setNo(String no){
        this.no = no;
    }
    public String getNo(){
        return this.no;
    }

    public void setInsuredAmount(BigDecimal insuredAmount){
        this.insuredAmount = insuredAmount;
    }
    public BigDecimal getInsuredAmount(){
        return this.insuredAmount;
    }

    public void setBillingDate(Date billingDate){
        this.billingDate = billingDate;
    }
    public Date getBillingDate(){
        return this.billingDate;
    }

    public void setStartDate(Date startDate){
        this.startDate = startDate;
    }
    public Date getStartDate(){
        return this.startDate;
    }

    public void setEndDate(Date endDate){
        this.endDate = endDate;
    }
    public Date getEndDate(){
        return this.endDate;
    }

}