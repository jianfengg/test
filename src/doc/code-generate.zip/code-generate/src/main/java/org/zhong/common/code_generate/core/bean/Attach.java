package org.zhong.common.code_generate.core.bean;

/**
 * 记录表里面的one to many 信息
 * @author 林建忠<303495267@qq.com>
 *
 */
public class Attach {

	private String tableName;
	private String entityName;
	private String fieldName;
	private String descr;
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getEntityName() {
		return entityName;
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	public String getDescr() {
		return descr;
	}
	public void setDescr(String descr) {
		this.descr = descr;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	
	
}
