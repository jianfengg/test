package org.zhong.common.code_generate.core.table_factory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.zhong.common.code_generate.core.bean.Column;
import org.zhong.common.code_generate.core.bean.Table;
import org.zhong.common.code_generate.core.utils.GenerateException;

public class SqlServerTableFactory extends TableFactory{

	public SqlServerTableFactory(){
		super();
	}
	public SqlServerTableFactory(Connection conn) {
		super(conn);
	}
	
	
	
	
	@Override
	public List<Table> getTables() throws GenerateException, SQLException {
		if(tableNames==null){
			throw new GenerateException("table列表为空");
		}
		List<Table> list = new ArrayList();
		for(int i=0;i<tableNames.length;i++){
			list.add(getTable(tableNames[i]));
		}
		return list;
	}
	
	@Override
	public Map<String, Table> getMapTables() throws GenerateException, SQLException {
		if(tableNames==null){
			throw new GenerateException("table列表为空");
		}
		Map<String,Table> map = new HashMap<String, Table>();
		for(int i=0;i<tableNames.length;i++){
			map.put(tableNames[i], getTable(tableNames[i]));
		}
		return map;
	}
	
	public Table getTable(String tableName) throws SQLException, GenerateException{
		Table table = new Table();
		PreparedStatement pst = getConn().prepareStatement(tablesql);
		ResultSet rs = null;
		pst.setString(1,tableName);
		rs = pst.executeQuery();
		int i=0;
		while(rs.next()){
			table.setTableName(tableName);
			table.setRemark(rs.getString("remark"));
			i++;
		}
		if(i<1){
			throw new GenerateException("请检查generate.xml的表名："+tableName+"配置是否与数据库一致");
		}
		convertTable(table);//配置其他信息
		table.setColumns(getColumns(tableName));
		return table;
	}
	
	private List<Column> getColumns(String tableName) throws SQLException{
		List<Column> list = new ArrayList<Column>();
		PreparedStatement pst = getConn().prepareStatement(columnsql);
		ResultSet rs = null;
		pst.setString(1,tableName);
		rs = pst.executeQuery();
		
		Column c = null;
		while(rs.next()){
			
			c = new Column();
			c.setIsnull(rs.getString("isnull"));
			c.setLength(rs.getString("length"));
			c.setName(rs.getString("name"));
			c.setRemark(rs.getString("remark"));
			c.setType(rs.getString("type"));
			c.setIsprimary(rs.getString("isprimary"));
			convertColumn(c);//配置其他信息
			list.add(c);
		}
		return list;
	}
	
	
	private String tablesql="select "   
						   + " tbl.table_name as name, "   
						   + " convert(VARCHAR(500) ,prop.value) as remark "
							+" FROM information_schema.tables tbl "
							+" LEFT JOIN sys.extended_properties prop "  
							+   " ON prop.major_id = object_id(tbl.table_schema + '.' + tbl.table_name)  "
							+   " AND prop.minor_id = 0  "
							+   " AND prop.name = 'MS_Description' "   
							+" WHERE tbl.TABLE_NAME = ? ";
		
	private String columnsql= "SELECT "
			 + "sys.columns.name as name ,"
			 +	"sys.types.name as type , "
			 +	"COLUMNPROPERTY(sys.columns.object_id,sys.columns.name,'PRECISION') as length,"
			+	"sys.columns.is_nullable as isnull,"
			+	"("
			+	"	SELECT"
			+	"		COUNT (*) "
			+	"	FROM "
			+	"		sys.identity_columns "
			+	"	WHERE "
			+	"		sys.identity_columns.object_id = sys.columns.object_id "
			+	"	AND sys.columns.column_id = sys.identity_columns.column_id "
			+	") AS isprimary, "
			+	"( "
			+	"	SELECT "
			+	"	convert(VARCHAR(200) ,value) "
			+	"	FROM "
			+	"		sys.extended_properties "
			+	"	WHERE " 
			+	"		sys.extended_properties.major_id = sys.columns.object_id "
			+	"	AND sys.extended_properties.minor_id = sys.columns.column_id "
			+	") AS remark "
			+	"FROM "
			+	"	sys.columns, "
			+	"	sys.tables, "
			+	"	sys.types "
			+	"WHERE "
			+	"	sys.columns.object_id = sys.tables.object_id "
			+	"AND sys.columns.system_type_id = sys.types.system_type_id "
			+   "AND sys.types.name !='sysname' "
			+	"AND sys.tables.name = ? "
			+	"ORDER BY "
			+	"	sys.columns.column_id";




	
}
