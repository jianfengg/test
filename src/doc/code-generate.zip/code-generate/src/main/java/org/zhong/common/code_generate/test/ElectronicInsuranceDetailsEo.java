import javax.persistence.Table;
import javax.persistence.Column;
import java.util.Date;
import com.dtyunxi.cube.framework.eo.CubeBaseEo;
import java.math.BigDecimal;

/**
*  电子保单详情Eo对象
*/
@Table(name="mt_electronic_insurance_details")
public class ElectronicInsuranceDetailsEo extends CubeBaseEo{
    /**
     *  描述
     *  
     */
    @Column(name = "remark")
    private String remark;

    /**
     *  主单id
     *  
     */
    @Column(name = "master_id")
    private Long masterId;

    /**
     *  保险公司
     *  
     */
    @Column(name = "insurance_company")
    private String insuranceCompany;

    /**
     *  所属险种
     *  
     */
    @Column(name = "insurance_type")
    private Integer insuranceType;

    /**
     *  保险产品
     *  
     */
    @Column(name = "insurance_product")
    private String insuranceProduct;

    /**
     *  保单号
     *  
     */
    @Column(name = "no")
    private String no;

    /**
     *  保险金额
     *  
     */
    @Column(name = "insured_amount")
    private BigDecimal insuredAmount;

    /**
     *  开单日期
     *  
     */
    @Column(name = "billing_date")
    private Date billingDate;

    /**
     *  保险起期
     *  
     */
    @Column(name = "start_date")
    private Date startDate;

    /**
     *  保险止期
     *  
     */
    @Column(name = "end_date")
    private Date endDate;


    public void setRemark(String remark){
        this.remark = remark;
    }
    public String getRemark(){
        return this.remark;
    }

    public void setMasterId(Long masterId){
        this.masterId = masterId;
    }
    public Long getMasterId(){
        return this.masterId;
    }

    public void setInsuranceCompany(String insuranceCompany){
        this.insuranceCompany = insuranceCompany;
    }
    public String getInsuranceCompany(){
        return this.insuranceCompany;
    }

    public void setInsuranceType(Integer insuranceType){
        this.insuranceType = insuranceType;
    }
    public Integer getInsuranceType(){
        return this.insuranceType;
    }

    public void setInsuranceProduct(String insuranceProduct){
        this.insuranceProduct = insuranceProduct;
    }
    public String getInsuranceProduct(){
        return this.insuranceProduct;
    }

    public void setNo(String no){
        this.no = no;
    }
    public String getNo(){
        return this.no;
    }

    public void setInsuredAmount(BigDecimal insuredAmount){
        this.insuredAmount = insuredAmount;
    }
    public BigDecimal getInsuredAmount(){
        return this.insuredAmount;
    }

    public void setBillingDate(Date billingDate){
        this.billingDate = billingDate;
    }
    public Date getBillingDate(){
        return this.billingDate;
    }

    public void setStartDate(Date startDate){
        this.startDate = startDate;
    }
    public Date getStartDate(){
        return this.startDate;
    }

    public void setEndDate(Date endDate){
        this.endDate = endDate;
    }
    public Date getEndDate(){
        return this.endDate;
    }

}