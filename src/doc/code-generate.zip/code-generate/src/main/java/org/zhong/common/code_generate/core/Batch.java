package org.zhong.common.code_generate.core;

import java.io.IOException;
import java.sql.SQLException;

public interface Batch {

	public void bacth(String tableName) throws Exception;
}
