package org.zhong.common.code_generate.core.table_factory;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.zhong.common.code_generate.core.analysis.Analysis;
import org.zhong.common.code_generate.core.bean.Attach;
import org.zhong.common.code_generate.core.bean.Column;
import org.zhong.common.code_generate.core.bean.Table;
import org.zhong.common.code_generate.core.utils.GenerateException;


public abstract class  TableFactory {
	private static final Logger logger = LoggerFactory.getLogger(Analysis.class) ;
	private Connection conn;
	protected String[] tableNames;
	protected DataSource dataSource;
	protected Analysis analysis;
	protected String dbName;

	public abstract List<Table> getTables() throws GenerateException, SQLException;

	public abstract Map<String,Table> getMapTables() throws GenerateException, SQLException;

	public TableFactory(){

	}
	public TableFactory(Connection conn){
		this.conn = conn;
	}

	public TableFactory(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	public String[] getTableNames() {
		return tableNames;
	}

	public void setTableNames(String[] tableNames) {
		this.tableNames = tableNames;
	}

	public Connection getConn() throws SQLException {
		if(dataSource!=null){
			try {
				conn = dataSource.getConnection();
			} catch (SQLException e) {

				if(conn!=null){
					logger.debug("从连接池获取连接异常.直接获取连接");
					return conn;
				}else{
					e.printStackTrace();
					throw e;
				}
			}
		}
		return conn;
	}


	public void convertTable(Table table) {
		String entityName = analysis.entityName(table.getTableName().substring(3));
		String jspName = analysis.jspName(entityName);
		List<Attach> attachs = analysis.attach(table);
		table.setEntityName(entityName);
		table.setAttachs(attachs);

	}

	public void convertColumn(Column column){
		String javaName = analysis.javaName(column);
		String javaType = analysis.javaType(column);
		String foreignTableName = analysis.foreignTableName(column);
		String foreignKey = analysis.foreignKey(column);
		String descr = analysis.descr(column.getRemark());
		String fieldCnName = analysis.fieldCnName(column.getRemark());
//		String display = analysis.display(column);
		column.setJavaName(javaName);
		column.setJavaType(javaType);
		column.setForeignTableName(foreignTableName);
		column.setForeignKey(foreignKey);
		column.setDescr(descr.trim());
		column.setFieldCnName(fieldCnName.trim());
	//	column.setDisplay(display);
	}


	public void setConn(Connection conn) {
		this.conn = conn;
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public Analysis getAnalysis() {
		return analysis;
	}

	public void setAnalysis(Analysis analysis) {
		this.analysis = analysis;
	}

	public String getDbName() {
		return dbName;
	}

	public void setDbName(String dbName) {
		this.dbName = dbName;
	}








}
