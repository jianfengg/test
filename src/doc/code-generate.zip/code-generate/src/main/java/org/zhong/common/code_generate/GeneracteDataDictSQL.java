package org.zhong.common.code_generate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.zhong.common.code_generate.core.utils.FreeMarkers;

import freemarker.template.Configuration;
import freemarker.template.Template;

public class GeneracteDataDictSQL {

	static final String sp1 = "、";
	static final String sp2 = "，";

	public static void main(String[] str){

	   try {

			generate("渠道经营状态", "CH_channelStatus"," 1，在建、2，营业、3，停业、4，退网");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public static  void generate(String groupName,String groupCode , String str) throws IOException{
		// 还款类型 1,按天到期还款、2,按月分期还款、3,一次性还款、4,每月还息到期还本、5,一次性还款
			String[] list = str.trim().split(sp1);
			List<Map<String,String>> lista = new ArrayList<Map<String,String>>();
			for(String s : list){
				String[] sa = s.trim().split(sp2);
				Map<String,String> map = new HashMap<String,String>();
				map.put("name", sa[1].trim());
				map.put("value", sa[0].trim());
				lista.add(map);
			}
		   Configuration  cfg = FreeMarkers.getConfiguration("classpath:/org/zhong/common/code_generate/tpl");
		   Template template = cfg.getTemplate("generacteDataDictSQL.ftl","UTF-8");

		   Map<String,Object> model = new HashMap<String, Object>();
		   model.put("groupCode",groupCode);
		   model.put("keys",lista);
		   model.put("groupName", groupName);
		   String content = FreeMarkers.renderTemplate(template,model);
		   System.out.println(content);


	}
}
