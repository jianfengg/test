package org.zhong.common.code_generate.core.analysis;

import java.util.List;

import org.zhong.common.code_generate.core.bean.Attach;
import org.zhong.common.code_generate.core.bean.Column;
import org.zhong.common.code_generate.core.bean.Table;

public interface Analysis {

	/**
	 * 根据表名获取实体名
	 * @param tableName
	 * @return
	 */
	public String entityName(String tableName);

	public String jspName(String entityName);
	/**
	 * 根据数据库字段名或其他信息获取java实体字段名
	 */
	public String javaName(Column column);


	/**
	 * 数据库到javaType映射
	 * @param s
	 * @return
	 */
	public String javaType(Column column);

	public String display(Column column);

	/**
	 *
	 */
	public String foreignTableName(Column column);

	public String foreignKey(Column column);

	public String descr(String remark);

	public String fieldCnName(String remark);
	public List<Attach> attach(Table table);

	public String getTablePrefix();

}
