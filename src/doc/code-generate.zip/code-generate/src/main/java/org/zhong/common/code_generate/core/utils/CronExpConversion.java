package org.zhong.common.code_generate.core.utils;

/**
 * 页面设置转为UNIX cron expressions 转换类 CronExpConversion
 */
public class CronExpConversion {

	/**
	 * 转换时间和cron表达式
	 * @param times
	 * @return
	 */
	public String change(String times){
		String str = "";
		if(times.substring(0, 2).equals("每年")){
			String month = substr(times.substring(2, 4));
			String day = substr(times.substring(5,7));
			String hour = substr(times.substring(9,11));
			String min = substr(times.substring(12,14));
			String miao = substr(times.substring(15,17));
		//	System.out.println("@@"+times.substring(2, 4)+"@@"+times.substring(5,7)+"@@"+times.substring(9,11));
		//	System.out.println("@@"+times.substring(12,14)+"@@"+times.substring(15,17));
			str = miao + " " + min + " " + hour + " " + day + " " + month + " ? *";
		}else if(times.substring(0, 2).equals("每月")){//每月19号 00:00   '0 :0  0 19 * ?'
			
			String strValue[] = times.split(" ");
			String timeValue[] = strValue[1].split(":");
			String day = substr(strValue[0].substring(2, 4));
			String hour = substr(timeValue[0]);
			String min = substr(timeValue[1]);
			str = "0 "+min+" "+hour+" "+day+" * ?";
		}else if(times.substring(0, 2).equals("每周")){
			//每周星期1 00:00
			//System.out.println(times+"^^^^^^^^^^^^^^^^^每周星期1 00:00^^^^^^^^^^^^^^");
			String strValue[] = times.split(" ");
			String timeValue[] = strValue[1].split(":");
			String hour = substr(timeValue[0]);//时    
			String min = substr(timeValue[1]);//分  每周星期1 00:00
			//System.out.println("  "+hour+"   "+min+"     &&&&&&&&&&&&&&&&");
			str = "0 "+min+" "+hour+" "+"? * ";
			if(strValue[0].substring(2, strValue[0].length()).equals("星期1")){
				str = str + "MON";
			}else if(strValue[0].substring(2, strValue[0].length()).equals("星期2")){
				str = str + "TUE";
			}else if(strValue[0].substring(2, strValue[0].length()).equals("星期3")){
				str = str + "WED";
			}else if(strValue[0].substring(2, strValue[0].length()).equals("星期4")){
				str = str + "THU";
			}else if(strValue[0].substring(2, strValue[0].length()).equals("星期5")){
				str = str + "FRI";
			}else if(strValue[0].substring(2, strValue[0].length()).equals("星期6")){
				str = str + "SAT";
			}else if(strValue[0].substring(2, strValue[0].length()).equals("星期7")){
				str = str + "SUN";
			}
		}else if(times.substring(0, 2).equals("每天")){
			String strValue[] = times.split(" ");
			String timeValue[] = strValue[1].split(":");
			String hour = substr(timeValue[0]);//时
			String min = substr(timeValue[1]);//分
			String miao = substr(timeValue[2]);//秒	
			str = miao + " " + min + " " + hour + " * * ?";
		}else if(times.substring(0, 2).equals("每时")){	
			String strValue[] = times.split(" ");
			String timeValue[] = strValue[1].split(":");
			//String hour = substr(timeValue[0]);//时    0 0 0/1 * * ?
			String min = substr(timeValue[0]);//分
			String miao = substr(timeValue[1]);//秒	
			str = min + " " + miao + " 0/1" + " * * ?";
		}
		
		else{
			System.out.println("出错！！！！");
		}
		//System.out.println(str);
		return str;
	}
    
	/**
	 * 把00传进去，传出来0的
	 * @param string
	 * @return
	 */
	public static String substr(String string){
	//	System.out.println(string);
		if (string.substring(0, 1).equals("0")) {
			return string.substring(1, 2);
		}else {
			return string;
		}
		//int inte = Integer.valueOf(string);
		//return String.valueOf(inte);
	}
	
	public static void main(String[] args) {
		//new CronExpConversion().change("每年05月29日 00时01分27秒");
		//	new CronExpConversion().change("每周星期1 00:00");
		System.out.println(new CronExpConversion().change("每天 12:00:00"));
		
		
	}
}
