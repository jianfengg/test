package  org.zhong.common.code_generate.test;

import com.dtyunxi.huieryun.ds.BaseMapper;
import org.zhong.common.code_generate.test.ElectronicInsuranceDetailsEo;

/**
* 电子保单详情Mapper类
*/
public interface ElectronicInsuranceDetailsMapper extends BaseMapper<ElectronicInsuranceDetailsEo> {
}