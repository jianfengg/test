package org.zhong.common.code_generate.core.analysis;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;
import org.zhong.common.code_generate.core.bean.Attach;
import org.zhong.common.code_generate.core.bean.Column;
import org.zhong.common.code_generate.core.bean.Table;

public class DefaultAnalysis implements Analysis{
	private static final Logger logger = LoggerFactory.getLogger(Analysis.class) ;
	private Map<String,String> tableMap;
	private Map<String,String> columnMap = new HashMap<String, String>();
	private String tablePrefix="";
	/**
	 * 根据表名获取实体名
	 * @param tableName
	 * @return
	 */
	public  String entityName(String tableName2){
		//String tableName = table.getTableName();
		Assert.notNull(tableName2, "表名不能为空");
		String tableName = tableName2.replace(getTablePrefix(), "");
		String s[] = StringUtils.split(tableName, "_");
		String rs = s[0];
		if(s.length>1){
			for(int i=1;i<s.length;i++ ){
				rs+= StringUtils.capitalize(s[i]);
			}
		}
		return StringUtils.capitalize(rs);
	}
	public String jspName(String entityName){
		   String[] ss = entityName.split("(?<!^)(?=[A-Z])");
	        String rs = StringUtils.uncapitalize(ss[0]);
	        for(int i = 1 ;i < ss.length; i ++){
	           rs+="_"+StringUtils.uncapitalize(ss[i]);
	        }
			return rs;
	}
	/**
	 * 根据数据库字段名或其他信息获取java实体字段名
	 */
	public String javaName(Column column){
		Map<String,String> columnMap = column.getColumnMap();
		if(columnMap==null){
			columnRemark(column);
			columnMap = column.getColumnMap();
		}
		if(!(columnMap==null||columnMap.get("table")==null)){
			String s =  entityName(columnMap.get("table"));//当字段配置为外键的时候，则字段名外外键表实体名
			return StringUtils.uncapitalize(s);
		}else{
			String name = column.getName();
			String[] s = StringUtils.split(name, "_");
			if(s!=null){
				String rs = s[0];
				if(s.length>1){
					for(int i=1;i<s.length;i++ ){
						rs+= StringUtils.capitalize(s[i]);
					}
				}
				return StringUtils.uncapitalize(rs);
			}else{
				return StringUtils.uncapitalize(name);
			}

		}


	}

	public String javaType(Column column){
		Map<String,String> columnMap = column.getColumnMap();
		if(columnMap==null){
			columnRemark(column);
			columnMap = column.getColumnMap();
		}
		if(!(columnMap==null||columnMap.get("table")==null)){
			return entityName(columnMap.get("table"));
		}else{
			return tojavaType(column);
		}
	}

	public String display(Column column){
		Map<String,String> columnMap = column.getColumnMap();
		if(columnMap==null){
			columnRemark(column);
			columnMap = column.getColumnMap();
		}
		String d = columnMap.get("display");
		return d==null ? "0" : d;
	}
	/**
	 * 数据库到javaType映射
	 * @param s
	 * @return
	 */
	public String tojavaType(Column column) {
		String s2 = column.getType().toLowerCase();
		if("char".equals(s2)){
			return "String";
		}else if("varchar".equals(s2)||"nvarchar".equals(s2)){
			return "String";
		}else if("nchar".equals(s2)||"char".equals(s2)){
			return "String";
		}else if("text".equals(s2)||"ntext".equals(s2)){
			return "String";
		}else if("int".equals(s2)||"smallint".equals(s2)||"tinyint".equals(s2)){
			return "Integer";
		}else if("bigint".equals(s2)){
			return "Long";
		}else if("bit".equals(s2)){
			return "Boolean";
		}else if("datetime".equals(s2)){
			return "Date";
		}else if("date".equals(s2)){
			return "Date";
		}else if("decimal".equals(s2)){
			return "BigDecimal";
		}else if("float".equals(s2)){
			return "Double";
		}else if("money".equals(s2)||"samllmoney".equals(s2)){
			return "BigDecimal";
		}else if("numeric".equals(s2)){
			return "BigDecimal";
		}else {
			return "String";
		}
	}

	public String foreignTableName(Column column) {
		Map<String,String> columnMap = column.getColumnMap();
		if(columnMap==null){
			columnRemark(column);
			columnMap = column.getColumnMap();
		}
		if(!(columnMap==null||columnMap.get("table")==null)){
			return columnMap.get("table");
		}else{
			return null;
		}
	}

	public String foreignKey(Column column) {
		Map<String,String> columnMap = column.getColumnMap();
		if(columnMap==null){
			columnRemark(column);
			columnMap = column.getColumnMap();
		}
		if(!(columnMap==null||columnMap.get("table")==null)){
			return "1";
		}else{
			return "0";
		}
	}

	private void tableRemark(Table table){
		if(table.getRemark()==null)
			return;
		Map<String,Object> tableMap = new HashMap<String, Object>();
		String[] s = table.getRemark().split("@");
		if(s==null||s.length!=2)
			return;
		String info =s[1];
		String[] infos = info.split(",");
		if(infos!=null&&infos.length>0){
			for(String s2:infos){
				String[] p = new String[2];
				p[0] = s2.substring(0,s2.indexOf('='));
				p[1] = s2.substring(s2.indexOf('=')+1,s2.length());
				if(p.length!=2){
					logger.info("表:"+table.getTableName()+" 错误的注释语法:"+s2);
					return;
				}
				tableMap.put(p[0],p[1]);
			}
		}
		table.setTableMap(tableMap.size()>0 ? tableMap : null );
	}

	private void columnRemark(Column column){
		if(column.getRemark()==null)
			return;
		Map<String,String> columnMap = new HashMap<String, String>();
		String[] s = column.getRemark().split("@");
		if(s==null||s.length!=2)
			return;

		String info =s[1];
		String[] infos = info.split(",");
		if(infos!=null&&infos.length>0){
			for(String s2:infos){
				String[] p = s2.split("=");
				if(p.length!=2){
					logger.info("列:"+column.getName()+" 错误的注释语法:"+s2);
					return;
				}
				columnMap.put(p[0],p[1]);
			}
		}
		column.setColumnMap(columnMap.size()>0 ? columnMap : null );

	}


	public String descr(String remark) {
		if(remark==null){
			return "";
		}
		String[] s = remark.split("###");
		if(s!=null && s.length == 2 ){
			return s[1];
		}
		return "";
	}

	public String fieldCnName(String remark) {
		if(remark==null){
			return "";
		}
		String[] s = remark.split("###");
		if(s!=null){
			return s[0];
		}
		return "";
	}


	public List<Attach> attach(Table table) {
		Map<String,Object> tableMap = table.getTableMap();
		List<Attach> attachs=new ArrayList<Attach>();
		if(tableMap==null){
			tableRemark(table);
			tableMap = table.getTableMap();
		}
		if(!(tableMap==null||tableMap.get("table")==null)){
			String s1 = (String) tableMap.get("table");
			s1 = s1.replace(' ',(char) 0);
			List<String> list = new ArrayList<String>();
			aly(s1,list,table);
			for(String s : list){
				String[] s3 = s.split("&");
				Attach attach = new Attach();
				for(String s4 :s3){
					String[] s5 = s4.split("=");
					if(s5.length!=2){
						logger.info("表:"+table.getTableName()+" 错误的注释语法:"+s);
						break;
					}
					if(s5[0].equals("n")){
						attach.setTableName(s5[1]);
						attach.setEntityName(entityName(s5[1]));
					}else if(s5[0].equals("p")){
						attach.setFieldName(s5[1]);
					}else if(s5[0].equals("d")){
						attach.setDescr(s5[1]);
					}else{
						logger.info("不存在的配置属性:"+s5[0]);
					}
				}
				attachs.add(attach);
			}

		}else{
			return attachs;
		}
		return attachs;
	}
	public static String aly(String s , List<String> list,Table table){
		if(s.length()<2){
			list.clear();
			return "";
		}
		if(s.charAt(0)!='['||s.charAt(s.length()-1)!=']'){
			logger.debug("表:"+table.getTableName()+" 错误的注释语法:"+table.getRemark());
			list.clear();
			return "";
		}
		String s2 = s.substring(1,s.indexOf(']'));
		if(s2.indexOf('[')>0||s2.indexOf(']')>0){
			logger.info("表:"+table.getTableName()+" 错误的注释语法:"+table.getRemark());
			list.clear();
			return "";
		}
		list.add(s2);
		if(s.length()==s.indexOf(']')){
			list.clear();
			return "";
		}
		String s3 = s.substring(s.indexOf(']')+1);
		if(s3.length()>2)
			aly(s3,list,table);
		return "";

	}


	public String getTablePrefix() {
		return tablePrefix;
	}
	public void setTablePrefix(String tablePrefix) {
		this.tablePrefix = tablePrefix;
	}
	public static void main(String[] args) {

		List<String> list = new ArrayList<String>();
		aly("[n=表名&p=实体字段名&d=描述[tn=表名&p=实体字段名2&d=描述]",list,new Table());
		for(String s:list)
		System.out.println("333"+s);
	}

}
