package org.zhong.common.code_generate.core;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;
import org.zhong.common.code_generate.core.analysis.Analysis;
import org.zhong.common.code_generate.core.bean.Table;
import org.zhong.common.code_generate.core.config.Config;
import org.zhong.common.code_generate.core.table_factory.TableFactory;
import org.zhong.common.code_generate.core.utils.FileUtils;
import org.zhong.common.code_generate.core.utils.FreeMarkers;
import org.zhong.common.code_generate.core.utils.GenerateException;

import freemarker.template.Configuration;
import freemarker.template.Template;

public class Generater {
	private static final Logger logger = LoggerFactory.getLogger(Analysis.class) ;
	private TableFactory tableFactory;
	private Config config;
	private Configuration freemarkerConfiguration;
	private List<Table> tables;
	private Map<String,Table> tableMap;

	public void generateEo(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveEo())+"/"+table.getEntityName()+"Eo.java";
		generate(config.getTmplEo(),path,table,config);
	}

	public void generateDto(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveEo())+"/"+table.getEntityName()+"Dto.java";
		generate(config.getTmplDto(),path,table,config);
	}

	public void generateMapper(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveMapper())+"/"+table.getEntityName()+"Mapper.java";
		generate(config.getTmplMapper(),path,table,config);
	}

	public void generateDas(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveDas())+"/"+table.getEntityName()+"Das.java";
		generate(config.getTmplDas(),path,table,config);
	}


	public void generateICommandApi(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveICommandApi())+"/I"+table.getEntityName()+"Api.java";
		generate(config.getTmplICommandApi(),path,table,config);
	}

	public void generateCommandApi(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveCommandApi())+"/"+table.getEntityName()+"ApiImpl.java";
		generate(config.getTmplCommandApi(),path,table,config);
	}

	public void generateIQueryApi(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveEo())+"/I"+table.getEntityName()+"QueryApi.java";
		generate(config.getTmplIQueryApi(),path,table,config);
	}

	public void generateQueryApi(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveQueryApi())+"/"+table.getEntityName()+"QueryApiImpl.java";
		generate(config.getTmplQueryApi(),path,table,config);
	}

	public void generateICommandService(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveEo())+"/I"+table.getEntityName()+"Service.java";
		generate(config.getTmplICommandService(),path,table,config);
	}

	public void generateCommandService(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveICommandService())+"/"+table.getEntityName()+"ServiceImpl.java";
		generate(config.getTmplCommandService(),path,table,config);
	}

	public void generateIQueryService(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveIQueryService())+"/I"+table.getEntityName()+"QueryService.java";
		generate(config.getTmplIQueryService(),path,table,config);
	}

	public void generateQueryService(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveQueryService())+"/"+table.getEntityName()+"QueryServiceImpl.java";
		generate(config.getTmplQueryService(),path,table,config);
	}

	public void generateRest(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveRest())+"/"+table.getEntityName()+"Rest.java";
		generate(config.getTmplRest(),path,table,config);
	}

	public void generateAppRest(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveRest())+"/"+table.getEntityName()+"Rest.java";
		generate(config.getTmplAppRest(),path,table,config);
	}
	
	public void generatePageReqDto(String tableName) throws IOException, GenerateException, SQLException{
		Table table = checkTable(tableName);
		String path =config.path(config.getSaveRest())+"/"+table.getEntityName()+"PageReqDto.java";
		generate(config.getTmplPageReqDto(),path,table,config);
	}
	
	public void bacthGenerate(Batch batch) throws Exception{
		if(tables==null)
			tables=tableFactory.getTables();
		for(int i = 0;i<tables.size();i++){
			batch.bacth(tables.get(i).getTableName());
		}
	}

	public void bacthGenerate(String[] tables,Batch batch) throws Exception{
		if(tableMap==null)
			tableMap = tableFactory.getMapTables();
		for(String s :tables){
			if(tableMap.get(s)==null){
				logger.info("表:"+s+"不存在或者未配置");
			}
			batch.bacth(s);
		}

	}

	private Table checkTable(String tableName) throws GenerateException, SQLException{
		Assert.notNull(tableName, "表明不能为空");
		Table table= getTable(tableName);
		if(table==null)
			throw new GenerateException("找不到该表的信息:"+tableName);
		return table;

	}
	private Table getTable(String tableName) throws GenerateException, SQLException{
		if(tableMap==null)
			tableMap = tableFactory.getMapTables();
		return tableMap.get(tableName);
	}

	/**
	 *
	 * @param ftl 模板文件名
	 * @param savaPath 保存路径:完整的文件路径
	 * @param table 表信息
	 * @param cfg 模板配置对象
	 * @throws IOException
	 */
	public void generate(String ftl,String savaPath,Table table,Config cfg) throws IOException{
		Assert.notNull(ftl, "模板路径不能为空");
		Assert.notNull(savaPath, "保存路径不能为空");
		Template template = freemarkerConfiguration.getTemplate(ftl);
		Map model = new HashMap<String,Object>();
		model.put("table",table);
		model.put("cfg",cfg);
		model.put("tag","$");
		model.put("le","{");
		model.put("rg","}");
		String content = FreeMarkers.renderTemplate(template,model);
		writeFile(content, savaPath);
		logger.info("成功！:"+savaPath);
	}



	/**
	 * 将内容写入文件
	 * @param content
	 * @param filePath
	 */
	private static void writeFile(String content, String filePath) {
		try {
			if (FileUtils.createFile(filePath)){
				FileWriter fileWriter = new FileWriter(filePath, true);
				BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
				bufferedWriter.write(content);
				bufferedWriter.close();
				fileWriter.close();
			}else{
				logger.info("生成失败，文件已存在！");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}




	public TableFactory getTableFactory() {
		return tableFactory;
	}


	public void setTableFactory(TableFactory tableFactory) {
		this.tableFactory = tableFactory;
	}


	public Config getConfig() {
		return config;
	}


	public void setConfig(Config config) throws IOException {
		freemarkerConfiguration = FreeMarkers.getConfiguration(config.getTmpl());
		this.config = config;
	}


	public Configuration getFreemarkerConfiguration() {
		return freemarkerConfiguration;
	}


	public void setFreemarkerConfiguration(Configuration freemarkerConfiguration) {
		this.freemarkerConfiguration = freemarkerConfiguration;
	}


	public List<Table> getTableList() {
		return tables;
	}


	public void setTableList(List<Table> tableList) {
		this.tables = tableList;
	}


	public Map<String, Table> getTableMap() {
		return tableMap;
	}


	public void setTableMap(Map<String, Table> tableMap) {
		this.tableMap = tableMap;
	}





}
