package org.zhong.common.code_generate.test;

import javax.persistence.Table;
import javax.persistence.Column;
import java.util.Date;
import com.dtyunxi.cube.framework.eo.CubeBaseEo;
import java.math.BigDecimal;

/**
*  活动基本信息Eo对象
*
* @author 代码生成器
*/
@Table(name="mk_activity")
public class ActivityEo extends CubeBaseEo{



    /**
     *  活动标题 
     */
    @Column(name = "activity_title")
    private String activityTitle;


    /**
     *  活动副标题
     */
    @Column(name = "activity_subtitle")
    private String activitySubtitle;


    /**
     *  活动编码
     */
    @Column(name = "activity_code")
    private String activityCode;


    /**
     *  活动标签
     */
    @Column(name = "activity_label")
    private String activityLabel;


    /**
     *  活动说明 简短描述，非图文描述
     */
    @Column(name = "activity_descr")
    private String activityDescr;


    /**
     *  活动缩略图 活动列表的缩略图
     */
    @Column(name = "activity_thumbnail")
    private String activityThumbnail;


    /**
     *  活动排序
     */
    @Column(name = "activity_sort")
    private Integer activitySort;


    /**
     *  活动开始时间
     */
    @Column(name = "activity_begin_time")
    private Date activityBeginTime;


    /**
     *  活动结束时间
     */
    @Column(name = "activity_end_time")
    private Date activityEndTime;


    /**
     *  活动发布时间
     */
    @Column(name = "release_time")
    private Date releaseTime;


    /**
     *  预热开始时间
     */
    @Column(name = "preheat_begin_time")
    private Date preheatBeginTime;


    /**
     *  活动链接
     */
    @Column(name = "activity_url")
    private String activityUrl;


    /**
     *  活动二维码URL
     */
    @Column(name = "activity_qrcode_url")
    private String activityQrcodeUrl;


    /**
     *  活动类型 1：图文活动、2：优惠活动
     */
    @Column(name = "activity_type")
    private Integer activityType;


    /**
     *  活动状态 0：未开始、1：进行中、2、预热中、3：已结束、4：已下架、5：草稿
     */
    @Column(name = "activity_status")
    private Integer activityStatus;


    /**
     *  活动审核状态 0：未通过、1：已通过、2：待审核、3：未提交
     */
    @Column(name = "audit_status")
    private Integer auditStatus;


    /**
     *  活动分享标题
     */
    @Column(name = "share_title")
    private String shareTitle;


    /**
     *  活动分享描述
     */
    @Column(name = "share_descr")
    private String shareDescr;


    /**
     *  活动分享缩略图
     */
    @Column(name = "share_thumbnail")
    private String shareThumbnail;


    /**
     *  活动审核时间
     */
    @Column(name = "audit_time")
    private Date auditTime;




    /**
     *  阅读量
     */
    @Column(name = "read_num")
    private Long readNum;




    /**
     *  创建人ID
     */
    @Column(name = "create_person_id")
    private Long createPersonId;








    /**
     *  修改人ID
     */
    @Column(name = "update_person_id")
    private Long updatePersonId;












    public void setActivityTitle(String activityTitle){
        this.activityTitle = activityTitle;
    }
    public String getActivityTitle(){
        return this.activityTitle;
    }



    public void setActivitySubtitle(String activitySubtitle){
        this.activitySubtitle = activitySubtitle;
    }
    public String getActivitySubtitle(){
        return this.activitySubtitle;
    }



    public void setActivityCode(String activityCode){
        this.activityCode = activityCode;
    }
    public String getActivityCode(){
        return this.activityCode;
    }



    public void setActivityLabel(String activityLabel){
        this.activityLabel = activityLabel;
    }
    public String getActivityLabel(){
        return this.activityLabel;
    }



    public void setActivityDescr(String activityDescr){
        this.activityDescr = activityDescr;
    }
    public String getActivityDescr(){
        return this.activityDescr;
    }



    public void setActivityThumbnail(String activityThumbnail){
        this.activityThumbnail = activityThumbnail;
    }
    public String getActivityThumbnail(){
        return this.activityThumbnail;
    }



    public void setActivitySort(Integer activitySort){
        this.activitySort = activitySort;
    }
    public Integer getActivitySort(){
        return this.activitySort;
    }



    public void setActivityBeginTime(Date activityBeginTime){
        this.activityBeginTime = activityBeginTime;
    }
    public Date getActivityBeginTime(){
        return this.activityBeginTime;
    }



    public void setActivityEndTime(Date activityEndTime){
        this.activityEndTime = activityEndTime;
    }
    public Date getActivityEndTime(){
        return this.activityEndTime;
    }



    public void setReleaseTime(Date releaseTime){
        this.releaseTime = releaseTime;
    }
    public Date getReleaseTime(){
        return this.releaseTime;
    }



    public void setPreheatBeginTime(Date preheatBeginTime){
        this.preheatBeginTime = preheatBeginTime;
    }
    public Date getPreheatBeginTime(){
        return this.preheatBeginTime;
    }



    public void setActivityUrl(String activityUrl){
        this.activityUrl = activityUrl;
    }
    public String getActivityUrl(){
        return this.activityUrl;
    }



    public void setActivityQrcodeUrl(String activityQrcodeUrl){
        this.activityQrcodeUrl = activityQrcodeUrl;
    }
    public String getActivityQrcodeUrl(){
        return this.activityQrcodeUrl;
    }



    public void setActivityType(Integer activityType){
        this.activityType = activityType;
    }
    public Integer getActivityType(){
        return this.activityType;
    }



    public void setActivityStatus(Integer activityStatus){
        this.activityStatus = activityStatus;
    }
    public Integer getActivityStatus(){
        return this.activityStatus;
    }



    public void setAuditStatus(Integer auditStatus){
        this.auditStatus = auditStatus;
    }
    public Integer getAuditStatus(){
        return this.auditStatus;
    }



    public void setShareTitle(String shareTitle){
        this.shareTitle = shareTitle;
    }
    public String getShareTitle(){
        return this.shareTitle;
    }



    public void setShareDescr(String shareDescr){
        this.shareDescr = shareDescr;
    }
    public String getShareDescr(){
        return this.shareDescr;
    }



    public void setShareThumbnail(String shareThumbnail){
        this.shareThumbnail = shareThumbnail;
    }
    public String getShareThumbnail(){
        return this.shareThumbnail;
    }



    public void setAuditTime(Date auditTime){
        this.auditTime = auditTime;
    }
    public Date getAuditTime(){
        return this.auditTime;
    }






    public void setReadNum(Long readNum){
        this.readNum = readNum;
    }
    public Long getReadNum(){
        return this.readNum;
    }






    public void setCreatePersonId(Long createPersonId){
        this.createPersonId = createPersonId;
    }
    public Long getCreatePersonId(){
        return this.createPersonId;
    }












    public void setUpdatePersonId(Long updatePersonId){
        this.updatePersonId = updatePersonId;
    }
    public Long getUpdatePersonId(){
        return this.updatePersonId;
    }











}